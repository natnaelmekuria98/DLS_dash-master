from .LangPyramid import LangPyramid

__all__ = [
    "LangPyramid"
]